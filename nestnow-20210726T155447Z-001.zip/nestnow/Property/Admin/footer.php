<div class="footer">
     <div class="text"> |Mini Project|cmru|5th sem IT|</div>
     <div class="text1"><a href="about.php" class="footerlinks">About Us</a> &nbsp; |&nbsp; 
     <a href="Contact.php" class="footerlinks"> Contact us</a> </div>

  
     <div class="text">
   <a href="https://www.facebook.com/"> <img src="images/facebook.png" width="20" height="20" ></a>
   <a href="https://instagram.com"> <img src="images/instagram.png" width="20" height="20" /></a>
   <a href="https://twitter.com"> <img src="images/twitter.png" width="20" height="20" /></a>
   <a href="https://plus.google.com"> <img src="images/google-plus.png" width="20" height="20" /></a>
</div>  