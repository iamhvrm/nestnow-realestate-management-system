-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2020 at 07:21 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pms`
--

-- --------------------------------------------------------

--
-- Table structure for table `area_master`
--

CREATE TABLE `area_master` (
  `AreaId` int(11) NOT NULL,
  `AreaName` varchar(20) NOT NULL,
  `CityName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area_master`
--

INSERT INTO `area_master` (`AreaId`, `AreaName`, `CityName`) VALUES
(3, 'Anantapur', 'Anantapur'),
(4, 'Dharmavaram', 'Anantapur'),
(5, 'Gooty', 'Anantapur'),
(6, 'Guntakal', 'Anantapur'),
(7, 'Hindupur', 'Anantapur'),
(8, 'Kadiri', 'Anantapur'),
(9, 'Kakkalapalle', 'Anantapur'),
(10, 'Kalyandurg', 'Anantapur'),
(11, 'Narayanapuram', 'Anantapur'),
(12, 'Papampeta', 'Anantapur'),
(13, 'Rayadurg', 'Anantapur'),
(14, 'Somandepalle', 'Anantapur'),
(15, 'Tadipatri', 'Anantapur'),
(16, 'Uravakonda', 'Anantapur'),
(17, 'Yenumalapalle', 'Anantapur'),
(18, 'Anekal', 'Bangalore'),
(19, 'Attibele', 'Bangalore'),
(20, 'Bangalore city', 'Bangalore'),
(21, 'Bommasandra', 'Bangalore'),
(22, 'Chikkabanavara', 'Bangalore'),
(23, 'Chikkabidarakallu', 'Bangalore'),
(24, 'Dommasandra', 'Bangalore'),
(25, 'Hebbagodi', 'Bangalore'),
(26, 'Hunasamaranahalli', 'Bangalore'),
(27, 'Jigani', 'Bangalore'),
(28, 'Kadigenahalli', 'Bangalore'),
(29, 'Sarjapura', 'Bangalore'),
(30, 'Hebbal', 'Bangalore'),
(31, 'E-city', 'Bangalore'),
(32, 'Kengeri', 'Bangalore'),
(33, 'Banshankari', 'Bangalore'),
(34, 'Kr Puram', 'Bangalore');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `CategoryId` int(11) NOT NULL,
  `CategoryName` varchar(20) NOT NULL,
  `Category_Desc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`CategoryId`, `CategoryName`, `Category_Desc`) VALUES
(1, 'Residential', '2 BHK,3BHK, Flats'),
(2, 'Commercial space', '200 Sq.M,300 Sq.M');

-- --------------------------------------------------------

--
-- Table structure for table `city_master`
--

CREATE TABLE `city_master` (
  `CityId` int(11) NOT NULL,
  `StateName` varchar(20) NOT NULL,
  `CityName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city_master`
--

INSERT INTO `city_master` (`CityId`, `StateName`, `CityName`) VALUES
(5, 'ANDHRA PRADESH', 'Anantapur'),
(6, 'ANDHRA PRADESH', 'Chittoor'),
(7, 'ANDHRA PRADESH', 'East Godavari'),
(8, 'ANDHRA PRADESH', 'Guntur'),
(9, 'ANDHRA PRADESH', 'Krishna'),
(10, 'ANDHRA PRADESH', 'Kurnool'),
(11, 'ANDHRA PRADESH', 'Prakasam'),
(12, 'ANDHRA PRADESH', 'Srikakulam'),
(13, 'ANDHRA PRADESH', 'Sri Potti Sriramulu '),
(14, 'ANDHRA PRADESH', 'Visakhapatnam'),
(15, 'ANDHRA PRADESH', 'Vizianagaram'),
(16, 'ANDHRA PRADESH', 'West Godavari'),
(17, 'ANDHRA PRADESH', 'Y.S.R. (Cuddapah)'),
(18, 'KARNATAKA', 'Bagalkot'),
(19, 'KARNATAKA', 'Bangalore'),
(20, 'KARNATAKA', 'Bangalore Rural'),
(21, 'KARNATAKA', 'Belgaum'),
(22, 'KARNATAKA', 'Bellary'),
(23, 'KARNATAKA', 'Bidar'),
(24, 'KARNATAKA', 'Bijapur'),
(25, 'KARNATAKA', 'Chamarajanagar'),
(26, 'KARNATAKA', 'Chikkaballapura'),
(27, 'KARNATAKA', 'Chikmagalur '),
(28, 'KARNATAKA', 'Chitradurga'),
(29, 'KARNATAKA', 'Dakshina Kannada'),
(30, 'KARNATAKA', 'Davanagere'),
(31, 'KARNATAKA', 'Dharwad'),
(32, 'KARNATAKA', 'Gadag'),
(33, 'KARNATAKA', 'Gulbarga'),
(34, 'KARNATAKA', 'Hassan'),
(35, 'KARNATAKA', 'Haveri'),
(36, 'KARNATAKA', 'Kodagu'),
(37, 'KARNATAKA', 'Kolar'),
(38, 'KARNATAKA', 'Koppal'),
(39, 'KARNATAKA', 'Mandya'),
(40, 'KARNATAKA', 'Mysore'),
(41, 'KARNATAKA', 'Raichur'),
(42, 'KARNATAKA', 'Ramanagara'),
(43, 'KARNATAKA', 'Shimoga'),
(44, 'KARNATAKA', 'Tumkur'),
(45, 'KARNATAKA', 'Udupi'),
(46, 'KARNATAKA', 'Uttara Kannada'),
(47, 'KARNATAKA', 'Yadgir');

-- --------------------------------------------------------

--
-- Table structure for table `customer_reg`
--

CREATE TABLE `customer_reg` (
  `CustomerId` int(11) NOT NULL,
  `CustomerName` varchar(20) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `BirthDate` date NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_reg`
--

INSERT INTO `customer_reg` (`CustomerId`, `CustomerName`, `Address`, `City`, `Mobile`, `Email`, `Gender`, `BirthDate`, `UserName`, `Password`) VALUES
(4, 'test1', '11. test address', 'Bangalore', 1234567890, 'test1@test.com', 'Male', '2020-11-10', 'test1', 'test1'),
(5, 'test2', 'test2 address', 'Anantapur', 987654321, 'test2@test2.com', 'Male', '2020-11-03', 'test2', 'test2');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackId` int(11) NOT NULL,
  `CustomerName` varchar(20) NOT NULL,
  `EmailId` varchar(20) NOT NULL,
  `MobileNumber` varchar(10) NOT NULL,
  `Message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedbackId`, `CustomerName`, `EmailId`, `MobileNumber`, `Message`) VALUES
(1, 'Hemanth kori', 'japanhemanth@gmail.c', '9898989898', 'Helpful, thanks');

-- --------------------------------------------------------

--
-- Table structure for table `login_master`
--

CREATE TABLE `login_master` (
  `UserId` int(11) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_master`
--

INSERT INTO `login_master` (`UserId`, `UserName`, `Password`) VALUES
(1, 'admin', 'admin'),
(2, 'test', 'test'),
(3, 'sample', 'sample');

-- --------------------------------------------------------

--
-- Table structure for table `news_master`
--

CREATE TABLE `news_master` (
  `NewsId` int(11) NOT NULL,
  `News` varchar(200) NOT NULL,
  `NewsDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news_master`
--

INSERT INTO `news_master` (`NewsId`, `News`, `NewsDate`) VALUES
(3, 'hurry up', '2020-11-01'),
(5, 'More Than 2000 Properties sold.', '2013-08-23'),
(6, 'Buy and Sell property easily', '2020-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `property_image`
--

CREATE TABLE `property_image` (
  `ImageId` int(11) NOT NULL,
  `PropertyId` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `ImagePath` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property_image`
--

INSERT INTO `property_image` (`ImageId`, `PropertyId`, `Title`, `ImagePath`) VALUES
(1, 3, 'Front View', 'home.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `property_master`
--

CREATE TABLE `property_master` (
  `PropertyId` int(11) NOT NULL,
  `CategoryId` int(11) NOT NULL,
  `StateName` varchar(20) NOT NULL,
  `CityName` varchar(20) NOT NULL,
  `AreaName` varchar(50) NOT NULL,
  `PropertyName` varchar(50) NOT NULL,
  `PropertyImage` varchar(200) NOT NULL,
  `PropertyDesc` varchar(200) NOT NULL,
  `TotalArea` float NOT NULL,
  `PropertyAge` varchar(10) NOT NULL,
  `TotalRoom` int(11) NOT NULL,
  `Furnished` varchar(5) NOT NULL,
  `Parking` varchar(5) NOT NULL,
  `DistRail` int(11) NOT NULL,
  `PropertyCost` float NOT NULL,
  `Status` varchar(20) NOT NULL,
  `CustomerId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property_master`
--

INSERT INTO `property_master` (`PropertyId`, `CategoryId`, `StateName`, `CityName`, `AreaName`, `PropertyName`, `PropertyImage`, `PropertyDesc`, `TotalArea`, `PropertyAge`, `TotalRoom`, `Furnished`, `Parking`, `DistRail`, `PropertyCost`, `Status`, `CustomerId`) VALUES
(7, 1, 'ANDHRA PRADESH', 'Anantapur', 'Anantapur', 'big house', 'download.jfif', '2 floor house with all amenities', 2500, '2 Year', 5, 'Yes', 'Yes', 25, 25000000, 'Open', 4),
(8, 1, 'KARNATAKA', 'Bangalore', 'Bangalore city', 'Vilas', 'download (1).jfif', 'home in the center of the garden city', 1800, '2 Year', 5, 'Yes', 'Yes', 21, 8000000, 'Open', 5),
(9, 1, 'KARNATAKA', 'Bangalore', 'Anekal', 'abcd', 'Desktop-free-building-wallpaper.jpg', 'abcd', 1000, '1 Year', 1, 'Yes', 'Yes', 10, 5000000, 'Open', 4);

-- --------------------------------------------------------

--
-- Table structure for table `state_master`
--

CREATE TABLE `state_master` (
  `StateId` int(11) NOT NULL,
  `StateName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state_master`
--

INSERT INTO `state_master` (`StateId`, `StateName`) VALUES
(1, 'ANDHRA PRADESH'),
(2, 'ARUNACHAL PRADESH'),
(3, 'ASSAM'),
(4, 'BIHAR'),
(5, 'CHATTISGARH'),
(6, 'GOA'),
(7, 'GUJARAT'),
(8, 'HARYANA'),
(9, 'HIMACHAL PRADESH'),
(10, 'JAMMU KASHMIR'),
(11, 'JHARKHAND'),
(12, 'KARNATAKA'),
(13, 'KERALA'),
(14, 'MADHYA PRADESH'),
(15, 'MAHARASHTRA'),
(16, 'MANIPUR'),
(17, 'MEGHALAYA'),
(18, 'MIZRORAM'),
(19, 'NAGALAND'),
(20, 'ODISHA'),
(21, 'PUNJAB'),
(22, 'RAJASTHAN'),
(23, 'SIKKIM'),
(24, 'TAMIL NADU'),
(25, 'TELANGANA'),
(26, 'TRIPURA'),
(27, 'UTTAR PRADESH'),
(28, 'UTTARKHAND'),
(29, 'WEST BENGAL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_master`
--
ALTER TABLE `area_master`
  ADD PRIMARY KEY (`AreaId`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`CategoryId`);

--
-- Indexes for table `city_master`
--
ALTER TABLE `city_master`
  ADD PRIMARY KEY (`CityId`);

--
-- Indexes for table `customer_reg`
--
ALTER TABLE `customer_reg`
  ADD PRIMARY KEY (`CustomerId`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackId`);

--
-- Indexes for table `login_master`
--
ALTER TABLE `login_master`
  ADD PRIMARY KEY (`UserId`);

--
-- Indexes for table `news_master`
--
ALTER TABLE `news_master`
  ADD PRIMARY KEY (`NewsId`);

--
-- Indexes for table `property_image`
--
ALTER TABLE `property_image`
  ADD PRIMARY KEY (`ImageId`);

--
-- Indexes for table `property_master`
--
ALTER TABLE `property_master`
  ADD PRIMARY KEY (`PropertyId`);

--
-- Indexes for table `state_master`
--
ALTER TABLE `state_master`
  ADD PRIMARY KEY (`StateId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area_master`
--
ALTER TABLE `area_master`
  MODIFY `AreaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `city_master`
--
ALTER TABLE `city_master`
  MODIFY `CityId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `customer_reg`
--
ALTER TABLE `customer_reg`
  MODIFY `CustomerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FeedbackId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_master`
--
ALTER TABLE `login_master`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `news_master`
--
ALTER TABLE `news_master`
  MODIFY `NewsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `property_image`
--
ALTER TABLE `property_image`
  MODIFY `ImageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `property_master`
--
ALTER TABLE `property_master`
  MODIFY `PropertyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `state_master`
--
ALTER TABLE `state_master`
  MODIFY `StateId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
