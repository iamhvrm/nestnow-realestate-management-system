<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NESTNOW</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="css/style1.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	color: #1CBCFA;
	font-weight: bold;
}
.style2 {
	color: #FD821B;
	font-weight: bold;
}
-->
</style>
</head>
<body>
<div class="main">
  <?php
  include "Headermenu.php"
  ?>
  
  <div class="content">
    <div class="innercontent">
      <?php
	  include "left.php"
	  ?>
      <div class="rightpannel">
      <br/>
      <br/>
      <br/>

      <div>
    
      <div class="rightpannel">
        <div class="welcome">
          
          <div style="width:573px; height:auto;font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#3f3f3f; line-height:20px; text-align:justify">
          NestNow is  a leading Real estate managagement portal, You can sell, buy properties. 
          This Portal is designed to provide the facility using which customer can buy or sale 
          their properties such as land, shop and house. Just you have to register yourself on the web portal.
           Once you register yourself, you can upload information of the properties you want to sale and you
            can also search properties to buy. </div>
        </div>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
     
      
      </div>
        
      </div>
    </div>
  </div>
  <div>
   <?php
   include "footer.php"
   ?>
  </div>
</div>
</body>
</html>
