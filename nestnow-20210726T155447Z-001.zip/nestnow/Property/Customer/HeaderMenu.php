<div class="header">
    <div class="header1"><img src="images/logo.jpg" width="290" height="60" /></div>
    <div class="header2">
      <div id="container">
        <div id="mainmenu">
          <ul>
            <li><a href="index.php" class="a">Home</a></li>
            <li><a href="Profile.php" class="a">Profile</a></li>
            <li><a href="Buy.php" class="a">Buy</a></li>
            <li><a href="Sale.php" class="a">Sale</a></li>
           	<li><a href="Image.php" class="a">Image & Documents</a></li>
            <li><a href="Logout.php" class="a">Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>


  <div class="headerimage">
    <div class="headeriamge1">
      <div class="house" ><img src="images/big1.jpg" width="460" height="210"></div>
    </div>

    <div class="headerimage2">
      <img src="images/big2.jpg" width="270" height="210">
    </div>
   
  </div>